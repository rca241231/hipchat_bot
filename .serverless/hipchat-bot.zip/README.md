## Bots Bots Bots

This repo contains all of the specifications to bots.
